package com.yao.module;

/**
 * Created by yaozb on 15-4-11.
 */
public enum  MsgType {
    PING,ASK,REPLY,LOGIN
}
