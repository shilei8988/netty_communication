package com.yao.module;

import java.io.Serializable;

/**
 * Created by yaozb on 15-4-11.
 */
public class ReplyBody implements Serializable {
    private static final long serialVersionUID = 1L;
}
