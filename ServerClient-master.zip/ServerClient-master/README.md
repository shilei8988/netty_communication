# ServerClient
netty server client 自定义消息协议通讯 ，及心跳检测例子
